import React from "react";

export default function index() {
  return (
    <div>
      <h2>Lab2</h2>
    </div>
  );
}
