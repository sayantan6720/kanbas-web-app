import React from "react";

export default function index() {
  return (
    <div>
      <h2>Lab3</h2>
    </div>
  );
}
